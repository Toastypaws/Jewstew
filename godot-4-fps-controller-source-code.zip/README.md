Are you a game developer looking for a free FPS template for Godot 4? Look no further than this Godot 4 FPS Template! With basic shooting mechanics and movement controls, this template provides a great starting point for
your own FPS game.

I used resources to define each weapon and a state machine that controls which weapon resource the controller is using, the rest if just animation and stats. I've been able to swap out the default with a normal FPS rig in
10 minutes. The idea being that this can be used to rapid prototype a game and if you wanted to add in weapons/animations it's just a matter of creating them in blender or in godot itself.

Follow the my Youtube channel for regular updates on new features and tutorials. And the best part? You can download this template for free right here!

I also try to make regular videos to show what I've been doing behind the scenes on my Feel free to pop on over and check out some of those videos. Maybe even like and subscribe!

Download the Godot 4 FPS Template today and start building your own FPS game!
